<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscador</title>
    <link rel="stylesheet" href="estilo_buscador.css">
</head>
<body>
    <h1>Buscador</h1>
    <form action="buscador_cli.php" method="POST">
        <input type="text" name="termino" placeholder="Buscar...">
        <input type="submit" value="Buscar">
    </form>
    
</body>
</html>

<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $termino = $_POST['termino'];
    $termino = $conn->real_escape_string($termino);

    $sql = "SELECT * FROM clientes WHERE nombre LIKE '%$termino%' OR apellido LIKE '%$termino%' OR edad LIKE '%$termino%' OR hora LIKE '%$termino%' OR sexo LIKE '%$termino%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>Resultados de búsqueda:</h2>";
        echo "<table border='1'>";
        echo "<tr>
                  <th>Nombre</th>
                  <th>Apellido</th>
                  <th>Edad</th>
                  <th>Hora</th>
                  <th>Sexo</th>
              </tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                      <td>" . $row["nombre"]. "</td>
                      <td>" . $row["apellido"]. "</td>
                      <td>" . $row["edad"]. "</td>
                      <td>" . $row["hora"]. "</td>
                      <td>" . $row["sexo"]. "</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "0 resultados";
    }
}

$conn->close();
?>
