<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORMULARIO</title>
    <link rel="stylesheet" href="estilo_trabajadores.css">
</head>
<body>
    
<div class="conten">
  <div class="registro">
    <h1>FORMULARIO DE INSCRIPCIÓN DE TRABAJADORES</h1>	  
    <form method="POST" action="GuardarTrabajador.php">
        <div class="form-group">
          <label for="example">ID del Trabajador</label>
          <input type="text" class="form-control" name="ID_Trabajador">        
        </div>

        <div class="form-group">
          <label for="example">Nombre Completo</label>
          <input type="text" class="form-control" name="Nombre_Trabajador">        
        </div>

        <div class="form-group">
          <label for="example">Apellido</label>
          <input type="text" class="form-control" name="Apellido_Trabajador">        
        </div>

        <div class="form-group">
          <label for="example">Dirección</label>
          <input type="text" class="form-control" name="Direccion_Trabajador">         
        </div>

        <div class="form-group">
          <label for="example">Correo Electrónico</label>
          <input type="text" class="form-control" name="Correo_Trabajador">       
        </div>

        <div class="form-group">
          <label for="example">Contraseña</label>
          <input type="password" class="form-control" name="Contrasena_Trabajador">         
        </div>
        
        <div class="form-group">
          <label for="example">Confirmar Contraseña</label>
          <input type="password" class="form-control" name="Confirmar_Trabajador">         
        </div>

        <div class="form-group">
          <label for="example">Fecha de Nacimiento</label>
          <input type="date" class="form-control" name="Fecha_Trabajador">          
        </div>

        <div class="form-group">          
            <label>Sexo:</label><br>
            <label>Masculino</label>
            <input type="radio" name="Sexo_Trabajador" value="Masculino"><br>
            <label>Femenino</label>
            <input type="radio" name="Sexo_Trabajador" value="Femenino">        
        </div>

        <div class="form-group">
          <button type="submit" class="form-control btn btn-primary" id="btnIngresar">Ingresar</button>
        </div>	
      </form>
  </div>
</div>
</body>
</html>