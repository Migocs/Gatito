<?php
echo "<meta charset='UTF-8'>";

include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_tra = $_POST['ID_Trabajador'];
    $nombre_tra = $_POST['Nombre_Trabajador'];
    $apellido_tra = $_POST['Apellido_Trabajador'];
    $direccion_tra = $_POST['Direccion_Trabajador'];
    $correo_tra = $_POST['Correo_Trabajador'];
    $contrasena_tra = $_POST['Contrasena_Trabajador'];
    $confirmar_tra = $_POST['Confirmar_Trabajador'];
    $fecha_tra = $_POST['Fecha_Trabajador'];
    $sexo_tra = $_POST['Sexo_Trabajador'];

    // Sanitizar los datos
    $id_tra = $conn->real_escape_string($id_tra);
    $nombre_tra = $conn->real_escape_string($nombre_tra);
    $apellido_tra = $conn->real_escape_string($apellido_tra);
    $direccion_tra = $conn->real_escape_string($direccion_tra);
    $correo_tra = $conn->real_escape_string($correo_tra);
    $contrasena_tra = $conn->real_escape_string($contrasena_tra);
    $confirmar_tra = $conn->real_escape_string($confirmar_tra);
    $fecha_tra = $conn->real_escape_string($fecha_tra);
    $sexo_tra = $conn->real_escape_string($sexo_tra);

    $sql = "INSERT INTO trabajadores (id, nombre, apellido, direccion, correo_electronico, contrasena, confirmar_contrasena, fecha_de_nacimiento, sexo) VALUES ('$id_tra', '$nombre_tra', '$apellido_tra', '$direccion_tra', '$correo_tra', '$contrasena_tra', '$confirmar_tra', '$fecha_tra', '$sexo_tra')";

    if ($conn->query($sql) === TRUE) {
        echo "Se agregó un nuevo registro satisfactoriamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action=""></form>
    <a href="buscador_tra.php"><button>Ir a Buscar</button></a>
</body>
</html>