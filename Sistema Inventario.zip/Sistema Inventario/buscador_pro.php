<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscador</title>
    <link rel="stylesheet" href="estilo_buscador.css">
</head>
<body>
    <h1>Buscador</h1>
    <form action="buscador_pro.php" method="POST">
        <input type="text" name="termino" placeholder="Buscar...">
        <input type="submit" value="Buscar">
    </form>
    
</body>
</html>

<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $termino = $_POST['termino'];
    $termino = $conn->real_escape_string($termino);

    $sql = "SELECT * FROM productos WHERE id LIKE '%$termino%' OR nombre LIKE '%$termino%' OR categoria LIKE '%$termino%' OR precio LIKE '%$termino%' OR cantidad LIKE '%$termino%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>Resultados de búsqueda:</h2>";
        echo "<table border='1'>";
        echo "<tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Categoria</th>
                  <th>Precio</th>
                  <th>Cantidad</th>
              </tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                      <td>" . $row["id"]. "</td>
                      <td>" . $row["nombre"]. "</td>
                      <td>" . $row["categoria"]. "</td>
                      <td>" . $row["precio"]. "</td>
                      <td>" . $row["cantidad"]. "</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "0 resultados";
    }
}

$conn->close();
?>
